﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Recipe> _recipeList; // Assuming you have a recipe list

        public MainWindow()
        {
            InitializeComponent();
            InitializeFilters();
        }

        private void InitializeFilters()
        {
            // Initialize the Calories Filter Slider range
            int minCalories = 0;
            int maxCalories = 1000;
            CaloriesFilter.Minimum = minCalories;
            CaloriesFilter.Maximum = maxCalories;
            CaloriesFilter.Value = maxCalories;

            // Set the initial Ingredient Filter TextBox text
            IngredientFilter.Text = "Search by Ingredient";
            IngredientFilter.Foreground = Brushes.Gray;

            // Select the "All" category in the Category Filter ComboBox
            CategoryFilter.SelectedIndex = 0;
        }

        private void IngredientFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Handle the Ingredient Filter TextBox TextChanged event
            string ingredientFilter = IngredientFilter.Text;
            FilterRecipesByIngredient(ingredientFilter);
        }

        private void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Handle the Category Filter ComboBox SelectionChanged event
            string selectedCategory = (e.AddedItems[0] as ComboBoxItem)?.Content.ToString();
            FilterRecipesByCategory(selectedCategory);
        }

        private void CaloriesFilter_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Handle the Calories Filter Slider ValueChanged event
            int minCalories = (int)CaloriesFilter.Minimum;
            int maxCalories = (int)e.NewValue;
            FilterRecipesByCalories(minCalories, maxCalories);
        }

        private void FilterRecipesByIngredient(string ingredientFilter)
        {
            // Implement the logic to filter the recipe list by ingredient
            // Update the UI with the filtered recipe list
        }

        private void FilterRecipesByCategory(string selectedCategory)
        {
            // Implement the logic to filter the recipe list by category
            // Update the UI with the filtered recipe list
        }

        private void FilterRecipesByCalories(int minCalories, int maxCalories)
        {
            // Implement the logic to filter the recipe list by calorie range
            // Update the UI with the filtered recipe list
        }
    }

    internal class Recipe
    {
    }
}