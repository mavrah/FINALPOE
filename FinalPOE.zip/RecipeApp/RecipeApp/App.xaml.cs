﻿using System.Configuration;
using System.Data;
using System.Windows;
using System.Windows.Controls;


namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;
        private List<Recipe> menu;

        public MainWindow()
        {
            InitializeComponent();
            LoadRecipes();
          
            UpdateRecipeList();

            // Wire up event handlers
            IngredientFilter.TextChanged += IngredientFilter_TextChanged;
            FoodGroupFilter.SelectionChanged += FoodGroupFilter_SelectionChanged;
            CaloriesFilter.ValueChanged += CaloriesFilter_ValueChanged;
            FilterButton.Click += FilterButton_Click;
            AddToMenuButton.Click += AddToMenuButton_Click;
            RemoveFromMenuButton.Click += RemoveFromMenuButton_Click;
        }

        private void LoadRecipes()
        {
            // Load recipe data from a data source (e.g., database, JSON file, etc.)
            recipes = new List<Recipe>
{
new Recipe { Name = "Grilled Chicken", Ingredients = new List<string> { "chicken", "salt", "pepper" }, FoodGroup = "Proteins", Calories = 300 },
new Recipe { Name = "Vegetable Stir-Fry", Ingredients = new List<string> { "broccoli", "carrots", "onion", "garlic" }, FoodGroup = "Vegetables", Calories = 200 },
new Recipe { Name = "Beef Lasagna", Ingredients = new List<string> { "ground beef", "tomato sauce", "pasta", "cheese" }, FoodGroup = "Proteins", Calories = 450 }
};

            menu = new List<Recipe>();
        }

        private void PopulateFoodGroupFilter()
        {
            // Get the unique food groups from the recipe data
            var foodGroups = recipes.Select(r => r.FoodGroup).Distinct().ToList();

            // Add the food groups to the FoodGroupFilter ComboBox
            foreach (var foodGroup in foodGroups)
            {
                FoodGroupFilter.Items.Add(new ComboBoxItem { Content = foodGroup });
            }

            // Set the initial selected item to "All"
            FoodGroupFilter.SelectedIndex = 0;
        }

        private void UpdateRecipeList()
        {
            // Filter the recipes based on the selected filters
            var filteredRecipes = FilterRecipes();

            // Update the RecipeList
            RecipeList.ItemsSource = filteredRecipes;
        }

        private List<Recipe> FilterRecipes()
        {
            var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Contains(IngredientFilter.Text, StringComparison.OrdinalIgnoreCase)));

            if (FoodGroupFilter.SelectedIndex > 0)
            {
                var selectedFoodGroup = ((ComboBoxItem)FoodGroupFilter.SelectedItem).Content.ToString();
                filteredRecipes = filteredRecipes.Where(r => r.FoodGroup == selectedFoodGroup);
            }

            if ((int)CaloriesFilter.Value > 0)
            {
                filteredRecipes = filteredRecipes.Where(r => r.Calories <= (int)CaloriesFilter.Value);
            }

            return filteredRecipes.ToList();
        }

        private void IngredientFilter_TextChanged(object sender, EventArgs e)
        {
            UpdateRecipeList();
        }

        private void FoodGroupFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateRecipeList();
        }

        private void CaloriesFilter_ValueChanged(object sender, EventArgs e)
        {
            UpdateRecipeList();
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateRecipeList();
        }

        private void AddToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Add the selected recipes to the menu
            var selectedRecipes = RecipeList.SelectedItems.Cast<Recipe>().ToList();
            menu.AddRange(selectedRecipes);
            UpdateMenuDisplay();
        }

        private void RemoveFromMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Remove the selected recipes from the menu
            var selectedRecipes = menu.Where(r => RecipeList.SelectedItems.Contains(r)).ToList();
            selectedRecipes.ForEach(r => menu.Remove(r));
            UpdateMenuDisplay();
        }

        private void UpdateMenuDisplay()
        {
            // Clear any existing items from the menu display
            MenuListBox.Items.Clear();

            // Iterate through the list of menu items
            foreach (var recipe in menu)
            {
                // Add each recipe to the menu display
                MenuListBox.Items.Add(recipe.Name);
            }
        }
        public class Recipe
        {
            public string Name { get; set; }
            public List<string> Ingredients { get; set; }
            public string FoodGroup { get; set; }
            public int Calories { get; set; }
        }
    }


  
}
